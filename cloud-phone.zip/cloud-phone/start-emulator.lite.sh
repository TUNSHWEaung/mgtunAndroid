#!/bin/bash
# Cloud Phone Lite - Start Emulator (No KVM)

set -e

echo "🚀 Starting Android emulator (Lite - Software Emulation)..."

# Set defaults
SCREEN_RESOLUTION="${SCREEN_RESOLUTION:-800x600}"
SCREEN_DENSITY="${SCREEN_DENSITY:-160}"
RAM_SIZE="${RAM_SIZE:-2048}"
BOOT_TIMEOUT="${BOOT_TIMEOUT:-900}"

# Parse resolution
WIDTH=$(echo $SCREEN_RESOLUTION | cut -d'x' -f1)
HEIGHT=$(echo $SCREEN_RESOLUTION | cut -d'x' -f2)

# Build QEMU command (software emulation)
QEMU_CMD="qemu-system-x86_64"
QEMU_CMD="$QEMU_CMD -m ${RAM_SIZE}M"
QEMU_CMD="$QEMU_CMD -smp 2"
QEMU_CMD="$QEMU_CMD -vga virtio"
QEMU_CMD="$QEMU_CMD -display none"
QEMU_CMD="$QEMU_CMD -vnc :0"
QEMU_CMD="$QEMU_CMD -boot d"
QEMU_CMD="$QEMU_CMD -cdrom /opt/android/android.iso"
QEMU_CMD="$QEMU_CMD -hda /data/android.qcow2"
QEMU_CMD="$QEMU_CMD -net nic -net user"
QEMU_CMD="$QEMU_CMD -accel tcg,thread=multi"

# Add USB for ADB
QEMU_CMD="$QEMU_CMD -device qemu-xhci,id=xhci"
QEMU_CMD="$QEMU_CMD -device usb-host,vendorid=0x18d1,productid=0x4ee2"

echo "📱 Launching emulator with: $QEMU_CMD"

# Start QEMU in background
$QEMU_CMD &

# Start Xvfb for VNC
Xvfb :99 -screen 0 ${WIDTH}x${HEIGHT}x24 &
export DISPLAY=:99

# Start x11vnc for web access
x11vnc -display :99 -forever -nopw -rfbport 6080 -quiet &

# Wait for boot
echo "⏳ Waiting for Android to boot (timeout: ${BOOT_TIMEOUT}s)..."
echo "⏳ This may take 5-10 minutes without KVM..."

TIMEOUT=$BOOT_TIMEOUT
BOOTED=false

while [ $TIMEOUT -gt 0 ]; do
    # Try ADB connection
    adb connect localhost:5555 2>/dev/null
    
    # Check if device is connected
    if adb devices | grep -q "5555.*device"; then
        echo "✅ Android booted!"
        BOOTED=true
        break
    fi
    
    sleep 10
    TIMEOUT=$((TIMEOUT - 10))
    echo "⏳ Still booting... ($((TIMEOUT/60))m remaining)"
done

if [ "$BOOTED" = false ]; then
    echo "⚠️ Boot timeout, but QEMU is still running..."
    echo "⚠️ You can try connecting via ADB: adb connect localhost:5555"
fi

# Post-boot optimization (if booted)
if [ "$BOOTED" = true ]; then
    echo "🔧 Optimizing for performance..."
    
    # Disable animations
    adb shell settings put global window_animation_scale 0.0
    adb shell settings put global transition_animation_scale 0.0
    adb shell settings put global animator_duration_scale 0.0
    
    # Set screen timeout
    adb shell settings put system screen_off_timeout 2147483647
    
    echo "✅ Cloud Phone Lite is ready!"
    echo "  Web Interface: http://localhost:8000"
    echo "  ADB: adb connect localhost:5555"
    echo "  VNC: vnc://localhost:6080"
fi

# Keep script running
wait
