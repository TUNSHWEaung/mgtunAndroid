---
name: 🐛 Bug Report
about: Create a report to help us improve
title: '[BUG] '
labels: 'bug'
assignees: ''
---

## 🐛 Bug Description

**Describe the bug**
A clear and concise description of what the bug is.

**Steps to Reproduce**
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

## 🖥️ Environment

**System:**
- OS: [e.g. Ubuntu 22.04]
- Docker version: [e.g. 24.0.7]
- Docker Compose version: [e.g. 2.21.0]
- Cloud Phone version: [e.g. 1.0.0]

**VPS/Cloud:**
- Provider: [e.g. Oracle Cloud, AWS, DigitalOcean]
- Instance type: [e.g. VM.Standard.A1.Flex]
- RAM: [e.g. 24GB]
- CPU: [e.g. 4 ARM cores]
- Storage: [e.g. 200GB]

**Configuration:**
- KVM enabled: [Yes/No]
- Screen resolution: [e.g. 1280x720]
- RAM allocated: [e.g. 4096MB]

## 📋 Logs

**Docker logs:**
```bash
docker compose logs cloud-phone
```

**Health check:**
```bash
docker compose exec cloud-phone /opt/scripts/health-check.sh
```

**System info:**
```bash
uname -a
docker version
docker compose version
```

## ➕ Additional Context

Add any other context about the problem here.
