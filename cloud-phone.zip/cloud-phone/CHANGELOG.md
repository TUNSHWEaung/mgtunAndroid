# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- GitHub Actions CI/CD (pending PAT workflow scope)

## [1.0.0] - 2026-05-31

### Added
- Initial release
- Android emulator with Docker
- Web interface via ws-scrcpy
- ARM64 translation support
- Root access with Magisk
- Google Play Store via MicroG
- Auto backup system
- Snapshot management
- Health monitoring
- VPN support (WireGuard)
- Monitoring stack (Prometheus + Grafana)
- Makefile for easy commands
- Setup script for quick installation
- Comprehensive documentation
- FAQ and troubleshooting guides
- Contributing guidelines

### Security
- Authentication for web interface
- ADB authentication option
- Network isolation
- Encrypted backup storage

## [0.1.0] - 2026-05-30

### Added
- Basic Android emulator
- Docker containerization
- ADB remote access
- VNC fallback

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-05-31 | Full feature release |
| 0.1.0 | 2026-05-30 | Initial prototype |
