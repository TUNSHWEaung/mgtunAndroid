# 📱 Cloud Phone Lite - Android for VPS without KVM

<div align="center">

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue?logo=docker)](https://www.docker.com/)

**Run Android on ANY VPS — no KVM needed!**

For students using GitHub Student Pack credits on VPS without KVM support.

</div>

---

## 🎯 What is Cloud Phone Lite?

Cloud Phone Lite adalah versi **optimized untuk VPS tanpa KVM**. Cocok untuk:

- 🎓 **Mahasiswa** pakai DigitalOcean/Azure $200 credit
- 💰 **Budget VPS** yang tidak support KVM
- 🧪 **Testing ringan** tanpa butuh performa tinggi

## ⚡ Key Differences

| Feature | Cloud Phone (Full) | Cloud Phone Lite |
|---------|-------------------|------------------|
| KVM Required | ✅ Yes | ❌ No |
| Performance | 60+ FPS | 15-30 FPS |
| RAM Usage | 4-8 GB | 2-4 GB |
| Storage | 20-50 GB | 10-20 GB |
| GPU Acceleration | ✅ Yes | ❌ No |
| Google Play Store | ✅ Yes | ⚠️ Limited |
| Root/Magisk | ✅ Yes | ⚠️ Limited |

## 🚀 Quick Start

### Prerequisites

| Requirement | Minimum | Recommended |
|------------|---------|-------------|
| CPU | 1 core | 2+ cores |
| RAM | 2 GB | 4+ GB |
| Storage | 10 GB | 20+ GB |
| KVM | ❌ Not needed | ❌ Not needed |

### Installation

**1. Clone repository:**
```bash
git clone https://github.com/0xN404T/cloud-phone.git -b lite
cd cloud-phone
```

**2. Configure:**
```bash
cp .env.lite.example .env
nano .env
```

**3. Start:**
```bash
docker compose -f docker-compose.lite.yml up -d
```

**4. Access:**
- Web Interface: `http://localhost:8000`
- ADB: `adb connect localhost:5555`

---

## ☁️ Student VPS Deployment

### DigitalOcean ($200 Credit)

```bash
# 1. Create Droplet
#    - Image: Ubuntu 22.04
#    - Plan: Regular (2 vCPU, 4GB RAM) = $24/month
#    - Storage: 50GB SSD
#    - Region: Singapore

# 2. SSH to droplet
ssh root@[DROPLET_IP]

# 3. Install Docker
apt update
apt install -y docker.io docker-compose-v2

# 4. Deploy Cloud Phone Lite
git clone https://github.com/0xN404T/cloud-phone.git -b lite
cd cloud-phone
cp .env.lite.example .env

# 5. Edit config
nano .env
# Set: RAM_SIZE=2048
# Set: AUTH_PASSWORD=yourpasswor...# 6. Start
docker compose -f docker-compose.lite.yml up -d

# 7. Check logs
docker compose -f docker-compose.lite.yml logs -f
```

**💰 Cost:** ~$24/month dari $200 credit = bisa jalan ~8 bulan

### Azure ($100 Credit)

```bash
# 1. Create VM
#    - Size: B2s (2 vCPU, 4GB RAM)
#    - Image: Ubuntu 22.04
#    - Disk: 32GB

# 2. Open ports
az vm open-port --port 8000 --resource-group [RG] --name [VM]
az vm open-port --port 5555 --resource-group [RG] --name [VM]

# 3. Deploy
ssh azureuser@[VM_IP]
# ... same as DigitalOcean
```

**💰 Cost:** ~$30/month dari $100 credit = bisa jalan ~3 bulan

---

## ⚙️ Configuration

### .env.lite.example

```env
# ===========================================
# Cloud Phone Lite Configuration
# ===========================================

# Display
SCREEN_RESOLUTION=800x600
SCREEN_DENSITY=160
RAM_SIZE=2048

# Features (limited without KVM)
ROOT_ENABLED=false
GAPPS_ENABLED=false
ARM_TRANSLATION=false

# Security
AUTH_ENABLED=*** AUTH_PASSWORD=changeme123

# Network
WEB_PORT=8000
ADB_PORT=5555

# Performance (optimized for no-KVM)
BOOT_TIMEOUT=900
VIDEO_BITRATE=4000000
MAX_RESOLUTION=800
```

### Optimization Tips

**Untuk 2GB RAM:**
```env
RAM_SIZE=1024
SCREEN_RESOLUTION=640x480
VIDEO_BITRATE=2000000
```

**Untuk 4GB RAM:**
```env
RAM_SIZE=2048
SCREEN_RESOLUTION=800x600
VIDEO_BITRATE=4000000
```

---

## 🔧 Technical Details

### How it Works (Without KVM)

```
┌─────────────────────────────────────────┐
│            Your VPS                     │
│  ┌─────────────────────────────────┐   │
│  │      Docker Container           │   │
│  │  ┌─────────────────────────┐    │   │
│  │  │   QEMU (Software Emu)   │    │   │
│  │  │   ┌─────────────────┐   │    │   │
│  │  │   │ Android x86_64  │   │    │   │
│  │  │   │   (Lite Image)   │   │    │   │
│  │  │   └─────────────────┘   │    │   │
│  │  └─────────────────────────┘    │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

### Performance Notes

- **No KVM = Software Emulation** — 10-20x slower than hardware
- **15-30 FPS** — cukup untuk basic tasks
- **Not suitable** untuk gaming atau heavy apps
- **Best for** productivity, testing, automation

---

## 📱 What Can You Do?

### ✅ Works Well
- Browse web
- Chat apps (WhatsApp, Telegram)
- Social media (Instagram, X)
- Notes & productivity
- Basic games (2D)

### ⚠️ Might Lag
- Video streaming
- Heavy apps
- 3D games
- Multi-tasking

### ❌ Not Recommended
- Gaming (Genshin, PUBG, etc)
- Video editing
- Heavy development

---

## 🛠️ Troubleshooting

### Slow Performance
```bash
# Reduce resolution
SCREEN_RESOLUTION=640x480

# Reduce RAM
RAM_SIZE=1024

# Disable features
ROOT_ENABLED=false
GAPPS_ENABLED=false
```

### Boot Timeout
```bash
# Increase timeout
BOOT_TIMEOUT=1200

# Check logs
docker compose -f docker-compose.lite.yml logs -f cloud-phone-lite
```

### Out of Memory
```bash
# Check usage
free -h

# Reduce emulator RAM
RAM_SIZE=1024

# Add swap
fallocate -l 2G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
```

---

## 💡 Tips for Students

### Maximize Your Credit

**DigitalOcean $200:**
- 2 vCPU, 4GB = $24/month → **8 bulan**
- 2 vCPU, 2GB = $12/month → **16 bulan**

**Azure $100:**
- B2s (2 vCPU, 4GB) = $30/month → **3 bulan**
- B1s (1 vCPU, 1GB) = $10/month → **10 bulan** (very limited)

### Backup Strategy
```bash
# Weekly backup
make backup

# Download to local
scp root@vps:/path/to/backups/* ./
```

### Share with Friends
```bash
# Multiple users access same emulator
# Add to .env:
AUTH_ENABLED=*** [YOUR_PASSWORD]
# Share URL: http://[VPS_IP]:8000
```

---

## 🔒 Security (Same as Full Version)

⚠️ **IMPORTANT:** Read [SECURITY.md](SECURITY.md)!

1. Change passwords in `.env`
2. Use VPN for remote access
3. Don't use for sensitive data

---

## 📊 Comparison with Alternatives

| Solution | KVM | Performance | Ease of Use | Cost |
|----------|-----|-------------|-------------|------|
| Cloud Phone Lite | ❌ | ⭐⭐ | ⭐⭐⭐⭐⭐ | Free |
| Google Colab | ❌ | ⭐⭐⭐ | ⭐⭐ | Free |
| Genymotion Cloud | ✅ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | $$ |
| AWS Device Farm | ✅ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | $$ |

---

## 🆘 Support

- GitHub Issues: https://github.com/0xN404T/cloud-phone/issues
- Telegram: @aiueth

---

*Made for students, by students! 🎓*
