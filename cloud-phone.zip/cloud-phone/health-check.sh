#!/bin/bash
# Cloud Phone - Health Check Script
# Used by Docker HEALTHCHECK

# Check if emulator is running
EMULATOR_PID=$(pgrep -f "emulator.*android")
if [ -z "$EMULATOR_PID" ]; then
    echo "❌ Emulator process not found"
    exit 1
fi

# Check if emulator is booted
BOOT_COMPLETE=$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')
if [ "$BOOT_COMPLETE" != "1" ]; then
    echo "⚠️ Emulator not fully booted"
    exit 1
fi

# Check ADB connection
ADB_STATE=$(adb get-state 2>/dev/null)
if [ "$ADB_STATE" != "device" ]; then
    echo "❌ ADB not connected"
    exit 1
fi

# Check system services
SERVICES_OK=$(adb shell dumpsys activity | grep -c "mStartedActivities" 2>/dev/null || echo "0")
if [ "$SERVICES_OK" -lt 1 ]; then
    echo "⚠️ Android services not running"
    exit 1
fi

echo "✅ All checks passed"
exit 0
