# 🔒 Security Policy

## ⚠️ IMPORTANT SECURITY WARNINGS

### 1. **JANGAN expose ke internet tanpa proteksi!**
Cloud Phone memberikan akses penuh ke Android emulator. Jika diakses orang lain:
- Mereka bisa login ke akun Google lo
- Mereka bisa install malware
- Mereka bisa akses data pribadi

### 2. **SELALU ganti default password!**
```bash
# Edit .env sebelum start
AUTH_PASSWORD=passwo...cker compose up -d
```

### 3. **Pakai VPN untuk akses remote!**
Jangan buka port 8000/5555 ke internet langsung. Pakai WireGuard:
```bash
# Start dengan VPN
docker compose --profile vpn up -d
```

### 4. **Jangan pakai untuk sensitive data!**
Emulator ini untuk:
- ✅ Development & testing
- ✅ Task automation
- ✅ Learning Android
- ❌ Banking atau financial transactions
- ❌ Login akun penting (email utama, dll)

---

## 🔐 Security Features

### Authentication
- Web interface password protection
- ADB authentication (optional)
- Session management

### Network Security
- Docker network isolation
- Optional VPN (WireGuard)
- Firewall-ready

### Data Protection
- Encrypted backups
- Snapshot system
- Secure defaults

---

## 🛡️ Security Best Practices

### Before Deployment

1. **Change ALL passwords in .env:**
   ```env
   AUTH_PASSWORD=yourstrong...asswo...rafockerypto -hex 32)
   ```

2. **Enable authentication:**
   ```env
   AUTH_ENABLED=***_AUTH_ENABLED=true
   ```

3. **Set up firewall:**
   ```bash
   sudo ufw default deny incoming
   sudo ufw default allow outgoing
   sudo ufw allow ssh
   sudo ufw allow 8000/tcp  # Only if needed
   sudo ufw allow 5555/tcp  # Only if needed
   sudo ufw enable
   ```

### During Use

1. **Use VPN for remote access:**
   ```bash
   docker compose --profile vpn up -d
   ```

2. **Monitor access logs:**
   ```bash
   docker compose logs -f | grep -E "(login|auth|connect)"
   ```

3. **Regular updates:**
   ```bash
   docker compose pull
   docker compose up -d
   ```

### After Use

1. **Stop when not in use:**
   ```bash
   docker compose down
   ```

2. **Regular backups:**
   ```bash
   make backup
   ```

3. **Clean sensitive data:**
   ```bash
   # Clear emulator data
   docker compose exec cloud-phone rm -rf /data/*
   docker compose restart
   ```

---

## 🚨 Security Checklist

Before going live:

- [ ] Changed all default passwords
- [ ] Enabled authentication
- [ ] Configured firewall
- [ ] Set up VPN (recommended)
- [ ] Tested backup/restore
- [ ] Reviewed .env file
- [ ] Checked Docker logs
- [ ] Updated to latest version

---

## 🐛 Reporting Security Issues

If you find a security vulnerability:

1. **DO NOT** open a public issue
2. **DO NOT** share exploit code publicly
3. **DO** contact: @aiueth on Telegram
4. **DO** provide detailed description

---

## 📋 Security Updates

| Version | Date | Security Fix |
|---------|------|--------------|
| 1.0.0 | 2026-05-31 | Initial release with auth |

---

*Stay safe! 🔒*
