#!/bin/bash
# Cloud Phone - Start Emulator Script

set -e

echo "🚀 Starting Android emulator..."

# Source environment
source /etc/environment 2>/dev/null || true

# Set defaults
SCREEN_RESOLUTION="${SCREEN_RESOLUTION:-1280x720}"
SCREEN_DENSITY="${SCREEN_DENSITY:-240}"
RAM_SIZE="${RAM_SIZE:-4096}"
ROOT_ENABLED="${ROOT_ENABLED:-true}"
BOOT_TIMEOUT="${BOOT_TIMEOUT:-600}"

# Build emulator command
EMULATOR_CMD="emulator -avd android -no-audio -no-window"

# Add resolution
WIDTH=$(echo $SCREEN_RESOLUTION | cut -d'x' -f1)
HEIGHT=$(echo $SCREEN_RESOLUTION | cut -d'x' -f2)
EMULATOR_CMD="$EMULATOR_CMD -skin ${WIDTH}x${HEIGHT}"

# Add memory
EMULATOR_CMD="$EMULATOR_CMD -memory $((RAM_SIZE / 1024))"

# Add density
EMULATOR_CMD="$EMULATOR_CMD -dpi-device $SCREEN_DENSITY"

# Enable KVM if available
if [ -e /dev/kvm ]; then
    echo "⚡ KVM acceleration enabled"
    EMULATOR_CMD="$EMULATOR_CMD -enable-kvm -gpu swiftshader_indirect"
else
    echo "⚠️ KVM not available, using software rendering"
    EMULATOR_CMD="$EMULATOR_CMD -gpu swiftshader_indirect -no-accel"
fi

# Add root access
if [ "${ROOT_ENABLED}" = "true" ]; then
    EMULATOR_CMD="$EMULATOR_CMD -root -writable-system"
fi

# Add custom arguments
if [ -n "${EMULATOR_ARGS}" ]; then
    EMULATOR_CMD="$EMULATOR_CMD ${EMULATOR_ARGS}"
fi

# Start ADB server
adb start-server

# Start emulator in background
echo "📱 Launching emulator with: $EMULATOR_CMD"
$EMULATOR_CMD &

# Wait for emulator to boot
echo "⏳ Waiting for emulator to boot (timeout: ${BOOT_TIMEOUT}s)..."
TIMEOUT=$BOOT_TIMEOUT
while [ $TIMEOUT -gt 0 ]; do
    # Check if emulator is booted
    BOOT_COMPLETE=$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')
    if [ "$BOOT_COMPLETE" = "1" ]; then
        echo "✅ Emulator booted successfully!"
        break
    fi
    sleep 5
    TIMEOUT=$((TIMEOUT - 5))
    echo "⏳ Still booting... ($((TIMEOUT/60))m remaining)"
done

if [ $TIMEOUT -le 0 ]; then
    echo "❌ Emulator failed to boot within timeout"
    exit 1
fi

# Post-boot setup
echo "🔧 Running post-boot setup..."

# Disable animations for better performance
adb shell settings put global window_animation_scale 0.0
adb shell settings put global transition_animation_scale 0.0
adb shell settings put global animator_duration_scale 0.0

# Set screen timeout to never
adb shell settings put system screen_off_timeout 2147483647

# Disable lock screen
adb shell settings put secure lockscreen.disabled 1

# Enable USB debugging
adb shell settings put global adb_enabled 1

# Install custom APKs
if [ -d /extras/apks ] && [ "$(ls -A /extras/apks/*.apk 2>/dev/null)" ]; then
    echo "📦 Installing custom APKs..."
    for apk in /extras/apks/*.apk; do
        echo "  Installing $(basename $apk)..."
        adb install -r "$apk" 2>/dev/null || echo "  ⚠️ Failed to install $(basename $apk)"
    done
fi

# Enable VNC for fallback access
echo "🖥️ Starting VNC server..."
Xvfb :99 -screen 0 ${SCREEN_RESOLUTION}x24 &
export DISPLAY=:99
x11vnc -display :99 -forever -nopw -rfbport 6080 -quiet &
sleep 2

echo "✅ Cloud Phone is ready!"
echo "  Web Interface: http://localhost:8000"
echo "  ADB: adb connect localhost:5555"
echo "  VNC: vnc://localhost:6080"

# Keep script running
wait
