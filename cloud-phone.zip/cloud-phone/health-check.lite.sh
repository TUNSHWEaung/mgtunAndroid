#!/bin/bash
# Cloud Phone Lite - Health Check

# Check if QEMU is running
QEMU_PID=$(pgrep -f "qemu-system.*android")
if [ -z "$QEMU_PID" ]; then
    echo "❌ QEMU process not found"
    exit 1
fi

# Try ADB connection
adb connect localhost:5555 2>/dev/null

# Check ADB connection
ADB_STATE=$(adb get-state 2>/dev/null || echo "offline")
if [ "$ADB_STATE" = "device" ]; then
    echo "✅ Android connected via ADB"
    exit 0
else
    # QEMU running but Android not fully booted yet
    echo "⚠️ QEMU running but Android not fully booted"
    exit 0  # Still healthy, just booting
fi
