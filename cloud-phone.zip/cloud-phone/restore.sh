#!/bin/bash
# Cloud Phone - Restore Script
# Restores emulator data from backup

set -e

BACKUP_DIR="${BACKUP_DIR:-/backups}"
BACKUP_FILE="$1"

# Show usage if no backup specified
if [ -z "$BACKUP_FILE" ]; then
    echo "Usage: $0 <backup-file>"
    echo ""
    echo "Available backups:"
    ls -lh "${BACKUP_DIR}"/cloud-phone-*.tar.gz 2>/dev/null || echo "  No backups found"
    exit 1
fi

# Check if backup exists
if [ ! -f "${BACKUP_FILE}" ] && [ ! -f "${BACKUP_DIR}/${BACKUP_FILE}" ]; then
    echo "❌ Backup file not found: ${BACKUP_FILE}"
    exit 1
fi

# Resolve full path
if [ -f "${BACKUP_FILE}" ]; then
    FULL_PATH="${BACKUP_FILE}"
else
    FULL_PATH="${BACKUP_DIR}/${BACKUP_FILE}"
fi

echo "🔄 Starting restore from: $(basename ${FULL_PATH})"

# Confirm restore
read -p "⚠️ This will overwrite current data. Continue? [y/N] " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Restore cancelled"
    exit 0
fi

# Stop emulator
echo "⏹️ Stopping emulator..."
adb emu kill 2>/dev/null || true
pkill -f "emulator.*android" 2>/dev/null || true
sleep 5

# Backup current data (just in case)
echo "💾 Creating safety backup of current data..."
SAFETY_BACKUP="${BACKUP_DIR}/pre-restore-$(date +%Y-%m-%d_%H-%M-%S).tar.gz"
tar -czf "${SAFETY_BACKUP}" -C /data . 2>/dev/null || true

# Clear current data
echo "🧹 Clearing current data..."
rm -rf /data/*
rm -rf /data/.* 2>/dev/null || true

# Restore from backup
echo "📦 Restoring from backup..."
tar -xzf "${FULL_PATH}" -C /data

# Mark setup as complete (skip first-boot on restore)
touch /data/.setup-complete

echo "✅ Restore complete!"
echo "🔄 Restart container to apply changes: docker compose restart"
