# 📱 Cloud Phone - Self-Hosted Android Emulator

<div align="center">

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue?logo=docker)](https://www.docker.com/)
[![GitHub Stars](https://img.shields.io/github/stars/0xN404T/cloud-phone?style=social)](https://github.com/0xN404T/cloud-phone)

**Run Android in your browser — no phone needed!**

[Features](#-features) • [Quick Start](#-quick-start) • [Documentation](#-documentation) • [Security](#-security)

</div>

---

## 🎯 What is Cloud Phone?

Cloud Phone adalah **Android emulator berbasis Docker** yang bisa diakses lewat browser. Cocok untuk:

- 📚 **Kerjain tugas** yang butuh Android app
- 🧪 **Testing aplikasi** tanpa HP fisik
- 🎮 **Main game Android** di browser
- 🔧 **Development** dengan akses ADB penuh

**Ada 2 versi:**
- **Cloud Phone** — Full version, butuh KVM (Oracle Cloud Free Tier)
- **[Cloud Phone Lite](README-LITE.md)** — Optimized untuk VPS tanpa KVM (Student VPS)

## ✨ Features

### Core Features
- 🌐 **Web Interface** — akses Android langsung dari browser
- 📱 **ARM64 Support** — bisa install app ARM/ARM64
- 🔑 **Root + Magisk** — full root access
- 🛒 **Google Play Store** — install app dari Play Store
- 🖥️ **ADB Remote** — connect dari mana saja
- 📹 **Screen Recording** — rekam layar emulator

### Security Features
- 🔒 **Encrypted Storage** — data emulator terenkripsi
- 🛡️ **Network Isolation** — emulator di network terpisah
- 🔐 **Optional VPN** — bisa integrate dengan WireGuard
- 📋 **Access Logs** — semua akses tercatat
- 🔄 **Auto Backup** — backup otomatis ke cloud

### Performance
- ⚡ **Hardware Acceleration** — pakai KVM untuk performa maksimal
- 🎨 **GPU Passthrough** — support GPU rendering
- 💾 **Snapshot** — simpan & restore state emulator
- 📊 **Resource Monitoring** — monitor CPU/RAM usage

## 🚀 Quick Start

### Prerequisites

| Requirement | Cloud Phone (Full) | Cloud Phone Lite |
|------------|-------------------|------------------|
| KVM | ✅ Required | ❌ Not needed |
| CPU | 2+ cores | 1+ core |
| RAM | 4+ GB | 2+ GB |
| Storage | 20+ GB | 10+ GB |
| Performance | 60+ FPS | 15-30 FPS |
| Best for | Gaming, Heavy apps | Basic tasks, Testing |

**Pilih versi:**
- **Full version** → KVM required → [Quick Start](#quick-start-1)
- **[Lite version](README-LITE.md)** → No KVM needed → [Student VPS guide](README-LITE.md)

| Requirement | Minimum | Recommended |
|------------|---------|-------------|
| CPU | 2 cores | 4+ cores |
| RAM | 4 GB | 8+ GB |
| Storage | 20 GB | 50+ GB |
| KVM | Required | Required |

**Check KVM support:**
```bash
egrep -c '(vmx|svm)' /proc/cpuinfo
# Output > 0 = KVM supported
```

### Installation

**1. Clone repository:**
```bash
git clone https://github.com/0xN404T/cloud-phone.git
cd cloud-phone
```

**2. Configure environment:**
```bash
cp .env.example .env
nano .env  # Edit configuration
```

**3. Start emulator:**
```bash
docker compose up -d
```

**4. Access:**
- Web Interface: `http://localhost:8000`
- ADB: `adb connect localhost:5555`

### First Boot

First boot takes **5-10 minutes** (installs Android system). Check progress:
```bash
docker compose logs -f cloud-phone
```

Wait for message: `✅ Emulator ready!`

## 📖 Documentation

- [README.md](README.md) — Overview & quick start
- [SECURITY.md](SECURITY.md) — Security policy & warnings ⚠️
- [FAQ.md](FAQ.md) — Frequently asked questions
- [CHANGELOG.md](CHANGELOG.md) — Version history
- [CONTRIBUTING.md](CONTRIBUTING.md) — How to contribute
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) — Cloud provider guides
- [LICENSE](LICENSE) — MIT license

### Configuration

Edit `.env` file:

```env
# Display Settings
SCREEN_RESOLUTION=1280x720
SCREEN_DENSITY=240
RAM_SIZE=4096

# Features
ROOT_ENABLED=true
GAPPS_ENABLED=true
ARM_TRANSLATION=true

# Security
VPN_ENABLED=false
VPN_CONFIG=./vpn/wireguard.conf
AUTO_BACKUP=true
BACKUP_SCHEDULE=daily

# Access
WEB_PORT=8000
ADB_PORT=5555
AUTH_ENABLED=true
AUTH_PASSWORD=your_secure_password
```

### Docker Commands

```bash
# Start
docker compose up -d

# Stop
docker compose down

# Restart
docker compose restart

# View logs
docker compose logs -f

# Shell access
docker compose exec cloud-phone bash

# Backup
docker compose exec cloud-phone /scripts/backup.sh

# Restore
docker compose exec cloud-phone /scripts/restore.sh backup.tar.gz
```

### ADB Commands

```bash
# Connect
adb connect localhost:5555

# List devices
adb devices

# Install APK
adb install app.apk

# Pull files
adb pull /sdcard/file.txt

# Push files
adb push file.txt /sdcard/

# Screen record
adb shell screenrecord /sdcard/recording.mp4
```

### Snapshots

```bash
# Create snapshot
docker compose exec cloud-phone /scripts/snapshot.sh create "my-snapshot"

# List snapshots
docker compose exec cloud-phone /scripts/snapshot.sh list

# Restore snapshot
docker compose exec cloud-phone /scripts/snapshot.sh restore "my-snapshot"
```

## 🔒 Security

### ⚠️ IMPORTANT WARNINGS

**JANGAN expose ke internet tanpa proteksi!** Cloud Phone memberikan akses penuh ke Android emulator.

**SEBELUM deploy:**
1. Ganti semua password di `.env`
2. Pakai VPN untuk akses remote
3. Jangan pakai untuk data sensitif (banking, email utama)

**Baca [SECURITY.md](SECURITY.md) untuk panduan lengkap!**

### Best Practices

1. **Change default password** — edit `AUTH_PASSWORD` in `.env`
2. **Enable VPN** — for remote access, use WireGuard
3. **Firewall rules** — only expose ports 8000 and 5555
4. **Regular backups** — enable `AUTO_BACKUP`
5. **Monitor logs** — check `docker compose logs` regularly

### Network Security

```
┌─────────────────────────────────────────┐
│            Your Server                  │
│  ┌─────────────────────────────────┐   │
│  │         Docker Network          │   │
│  │  ┌─────────┐    ┌─────────┐    │   │
│  │  │ Android │────│ scrcpy  │    │   │
│  │  │Emulator │    │  Web    │    │   │
│  │  └────┬────┘    └────┬────┘    │   │
│  │       │              │         │   │
│  └───────┼──────────────┼─────────┘   │
│          │              │             │
│     Port 5555      Port 8000         │
│          │              │             │
└──────────┼──────────────┼─────────────┘
           │              │
      [Firewall]     [Firewall]
           │              │
        ADB Only     Web Only
```

### Backup Strategy

Backups are stored in `./backups/` with timestamp:
```
backups/
├── cloud-phone-2026-05-31_12-00-00.tar.gz
├── cloud-phone-2026-06-01_12-00-00.tar.gz
└── ...
```

## 🌍 Deployment Options

### Free Tier Options

| Provider | Specs | KVM | Free Tier |
|----------|-------|-----|-----------|
| Oracle Cloud | 4 ARM cores, 24GB RAM | ✅ | Always Free |
| Google Cloud | e2-micro | ✅ | $300 credit |
| AWS | t2.micro | ✅ | 12 months free |
| Azure | B1s | ✅ | $200 credit |

### Recommended: Oracle Cloud Free Tier

```bash
# 1. Create Oracle Cloud account
# 2. Launch Ampere A1 instance (ARM)
# 3. SSH to instance
# 4. Install Docker
sudo apt update
sudo apt install docker.io docker-compose-v2 -y
sudo usermod -aG docker $USER

# 5. Clone and run
git clone https://github.com/0xN404T/cloud-phone.git
cd cloud-phone
docker compose up -d
```

## 🛠️ Troubleshooting

### Emulator won't start

```bash
# Check KVM
egrep -c '(vmx|svm)' /proc/cpuinfo

# Check Docker logs
docker compose logs cloud-phone

# Restart
docker compose down
docker compose up -d
```

### Slow performance

```bash
# Increase RAM in .env
RAM_SIZE=8192

# Enable KVM acceleration
KVM_ENABLED=true
```

### Can't connect via ADB

```bash
# Check if emulator is running
docker compose ps

# Restart ADB
adb kill-server
adb start-server
adb connect localhost:5555
```

## 📝 License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file.

## 🙏 Credits

Based on:
- [dockerify-android](https://github.com/Shmayro/dockerify-android) — Docker Android emulator
- [ws-scrcpy](https://github.com/nicehash/ws-scrcpy) — Web-based scrcpy
- [Magisk](https://github.com/topjohnwu/Magisk) — Root solution
- [MicroG](https://microg.org/) — Google Play Services alternative

## 📧 Support

- GitHub Issues: [Create Issue](https://github.com/0xN404T/cloud-phone/issues)
- Telegram: @aiueth

---

<div align="center">
Made with ❤️ by <a href="https://github.com/0xN404T">0xN404T</a>
</div>
