# Deployment Guide

## ☁️ Cloud Providers

### 🟢 Oracle Cloud Free Tier (Recommended)

**Specs:**
- 4 ARM cores (Ampere A1)
- 24GB RAM
- 200GB storage
- **GRATIS selamanya**

**Steps:**

1. **Daftar Oracle Cloud:**
   - https://www.oracle.com/cloud/free/
   - Butuh credit card (tidak dipotong)

2. **Create VM Instance:**
   ```bash
   # Instance shape: VM.Standard.A1.Flex
   # OCPU: 4
   # Memory: 24GB
   # Image: Ubuntu 22.04
   # Boot volume: 200GB
   ```

3. **Open ports di Security List:**
   ```
   Ingress Rule 1:
     Source: 0.0.0.0/0
     Protocol: TCP
     Destination Port: 8000 (Web)
   
   Ingress Rule 2:
     Source: 0.0.0.0/0
     Protocol: TCP
     Destination Port: 5555 (ADB)
   ```

4. **Connect via SSH:**
   ```bash
   ssh -i ssh-key.key ubuntu@[YOUR_IP]
   ```

5. **Install Docker:**
   ```bash
   sudo apt update
   sudo apt install -y docker.io docker-compose-v2
   sudo usermod -aG docker $USER
   newgrp docker
   ```

6. **Deploy Cloud Phone:**
   ```bash
   git clone https://github.com/0xN404T/cloud-phone.git
   cd cloud-phone
   cp .env.example .env
   # Edit .env sesuai kebutuhan
   docker compose up -d
   ```

7. **Akses:**
   - Web: http://[YOUR_IP]:8000
   - ADB: adb connect [YOUR_IP]:5555

---

### 🔵 Google Cloud

**Free Credit: $300 untuk 90 hari**

**Steps:**

1. **Daftar GCP:**
   - https://cloud.google.com/free
   - Dapat $300 credit

2. **Create VM Instance:**
   ```bash
   # Compute Engine → VM Instances → Create
   # Machine type: e2-standard-4 (4 vCPU, 16GB)
   # Boot disk: Ubuntu 22.04, 50GB SSD
   # Firewall: Allow HTTP/HTTPS traffic
   ```

3. **Open Firewall:**
   ```bash
   gcloud compute firewall-rules create cloud-phone-web \
     --allow tcp:8000 \
     --source-ranges 0.0.0.0/0 \
     --description "Cloud Phone Web Interface"
   
   gcloud compute firewall-rules create cloud-phone-adb \
     --allow tcp:5555 \
     --source-ranges 0.0.0.0/0 \
     --description "Cloud Phone ADB"
   ```

4. **SSH ke instance:**
   ```bash
   gcloud compute ssh [INSTANCE_NAME]
   ```

5. **Deploy:**
   ```bash
   # Same as Oracle Cloud
   sudo apt update
   sudo apt install -y docker.io docker-compose-v2
   git clone https://github.com/0xN404T/cloud-phone.git
   cd cloud-phone
   docker compose up -d
   ```

---

### 🟠 DigitalOcean

**Free Credit: $200 via GitHub Student Pack**

**Steps:**

1. **Apply GitHub Student Pack:**
   - https://education.github.com/pack
   - Dapat $200 DigitalOcean credit

2. **Create Droplet:**
   ```bash
   # Image: Ubuntu 22.04
   # Plan: Regular (4 vCPU, 8GB RAM)
   # Storage: 100GB SSD
   # Region: Singapore (terdekat)
   ```

3. **Deploy:**
   ```bash
   ssh root@[DROPLET_IP]
   
   # Install Docker
   apt update
   apt install -y docker.io docker-compose-v2
   
   # Deploy
   git clone https://github.com/0xN404T/cloud-phone.git
   cd cloud-phone
   docker compose up -d
   ```

---

### 🔴 AWS

**Free Tier: 12 bulan**

**Steps:**

1. **Create EC2 Instance:**
   ```bash
   # Instance type: t3.medium (2 vCPU, 4GB)
   # AMI: Ubuntu 22.04 LTS
   # Storage: 50GB gp3
   # Security Group: Allow 8000, 5555
   ```

2. **Deploy:**
   ```bash
   ssh -i key.pem ubuntu@[EC2_IP]
   
   sudo apt update
   sudo apt install -y docker.io docker-compose-v2
   sudo usermod -aG docker ubuntu
   
   git clone https://github.com/0xN404T/cloud-phone.git
   cd cloud-phone
   docker compose up -d
   ```

---

## 🔧 Configuration Tuning

### For 4GB RAM VPS
```env
RAM_SIZE=2048
SCREEN_RESOLUTION=800x600
VIDEO_BITRATE=4000000
```

### For 8GB RAM VPS
```env
RAM_SIZE=4096
SCREEN_RESOLUTION=1280x720
VIDEO_BITRATE=8000000
```

### For 16GB+ RAM VPS
```env
RAM_SIZE=8192
SCREEN_RESOLUTION=1920x1080
VIDEO_BITRATE=12000000
GPU_ENABLED=true
```

---

## 🔒 Security Hardening

### Firewall (UFW)
```bash
# Install UFW
sudo apt install ufw

# Default rules
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH
sudo ufw allow ssh

# Allow Cloud Phone ports
sudo ufw allow 8000/tcp
sudo ufw allow 5555/tcp

# Enable firewall
sudo ufw enable
```

### Fail2Ban (Brute Force Protection)
```bash
sudo apt install fail2ban

# Create jail config
sudo nano /etc/fail2ban/jail.local
```

```ini
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600
```

```bash
sudo systemctl restart fail2ban
```

### VPN (WireGuard)
```bash
# Install WireGuard
sudo apt install wireguard

# Generate keys
wg genkey | tee privatekey | wg pubkey > publickey

# Configure
sudo nano /etc/wireguard/wg0.conf
```

```ini
[Interface]
PrivateKey = YOUR_PRIVATE_KEY
Address = 10.0.0.1/24
ListenPort = 51820

[Peer]
PublicKey = PEER_PUBLIC_KEY
AllowedIPs = 10.0.0.2/32
```

```bash
sudo systemctl enable wg-quick@wg0
sudo systemctl start wg-quick@wg0
```

---

## 📊 Monitoring

### Enable Monitoring Stack
```bash
docker compose --profile monitoring up -d
```

### Access Grafana
- URL: http://[YOUR_IP]:3000
- Username: admin
- Password: (from GRAFANA_PASSWORD in .env)

### Set Up Alerts
```bash
# In Grafana, create alerts for:
# - CPU > 80%
# - RAM > 90%
# - Disk > 80%
# - Container down
```

---

## 🔄 Backup Strategy

### Daily Backups
```bash
# Edit .env
AUTO_BACKUP=true
BACKUP_SCHEDULE=0 2 * * *  # 2 AM daily
BACKUP_RETAIN=7
```

### Offsite Backup (Rclone)
```bash
# Install rclone
sudo apt install rclone

# Configure (e.g., Google Drive)
rclone config

# Create backup script
cat > /usr/local/bin/backup-cloud-phone.sh << 'EOF'
#!/bin/bash
cd /path/to/cloud-phone
docker compose exec cloud-phone /opt/scripts/backup.sh
rclone copy ./backups remote:cloud-phone-backups --min-age 1h
EOF

chmod +x /usr/local/bin/backup-cloud-phone.sh

# Add to crontab
crontab -e
0 3 * * * /usr/local/bin/backup-cloud-phone.sh
```

---

## 🚀 Performance Optimization

### Enable KVM
```bash
# Check KVM
ls -la /dev/kvm

# Fix permissions
sudo chmod 666 /dev/kvm

# Make permanent
sudo nano /etc/udev/rules.d/99-kvm.rules
```

```
KERNEL=="kvm", GROUP="kvm", MODE="0660"
```

### Enable GPU (NVIDIA)
```bash
# Install NVIDIA drivers
sudo apt install nvidia-driver-535

# Install NVIDIA Container Toolkit
distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/$distribution/libnvidia-container.list | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt update
sudo apt install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

# Enable in .env
GPU_ENABLED=true
```

### Optimize Docker
```bash
# Edit daemon.json
sudo nano /etc/docker/daemon.json
```

```json
{
  "storage-driver": "overlay2",
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

```bash
sudo systemctl restart docker
```

---

## 🆘 Troubleshooting

### Container won't start
```bash
# Check logs
docker compose logs cloud-phone

# Check KVM
ls -la /dev/kvm

# Check disk space
df -h

# Restart
docker compose down
docker compose up -d
```

### Slow performance
```bash
# Check resources
htop

# Check KVM
kvm-ok

# Increase RAM in .env
RAM_SIZE=8192

# Restart
docker compose restart
```

### Connection issues
```bash
# Check ports
sudo netstat -tlnp | grep -E '8000|5555'

# Check firewall
sudo ufw status

# Check Docker network
docker network ls
docker network inspect cloud-phone_cloud-phone-net
```

---

*Need help? Create an issue on GitHub!*
