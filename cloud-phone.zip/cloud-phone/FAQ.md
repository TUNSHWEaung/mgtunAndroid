# Frequently Asked Questions (FAQ)

## General

### Apa itu Cloud Phone?
Cloud Phone adalah Android emulator yang berjalan di server (VPS) dan bisa diakses dari browser. Kamu bisa pakai Android apps tanpa HP fisik.

### Berapa biayanya?
Software-nya **gratis** (open source). Yang butuh biaya adalah VPS:
- **Oracle Cloud Free Tier**: GRATIS selamanya (4 ARM cores, 24GB RAM)
- **Google Cloud**: $300 credit gratis
- **DigitalOcean**: $200 credit (via GitHub Student Pack)

### Apakah legal?
Ya, 100% legal. Ini emulator Android biasa, bukan hack atau crack.

## Technical

### Apa itu KVM? Kenapa harus ada?
KVM (Kernel-based Virtual Machine) adalah hardware acceleration untuk virtualisasi. Tanpa KVM, emulator akan **sangat lambat** (10x lebih lambat).

**Cek KVM:**
```bash
egrep -c '(vmx|svm)' /proc/cpuinfo
# Output > 0 = KVM tersedia
```

### VPS saya tidak ada KVM, bisa pakai?
Bisa, tapi sangat lambat. Rekomendasi:
- Oracle Cloud Free Tier (selalu ada KVM)
- Google Cloud e2-standard-4
- AWS t3.medium

### Berapa minimum RAM?
- **Minimum**: 4GB (bisa jalan, tapi lambat)
- **Recommended**: 8GB+ (smooth)
- **Ideal**: 16GB+ (buka banyak apps)

### Berapa minimum storage?
- **Minimum**: 20GB (Android system + basic apps)
- **Recommended**: 50GB (banyak apps)
- **Ideal**: 100GB+ (games + media)

### Kenapa boot pertama lama?
Boot pertama butuh 5-10 menit karena:
1. Membuat virtual disk
2. Install Android system
3. Setup ARM translation
4. Install Google services

Boot kedua+ hanya butuh 1-2 menit.

### Bagaimana cara install APK?
**Via Web Interface:**
1. Buka http://localhost:8000
2. Drag & drop APK ke emulator

**Via ADB:**
```bash
adb connect localhost:5555
adb install app.apk
```

**Via extras folder:**
1. Letakkan APK di `extras/apks/`
2. Restart container: `docker compose restart`

### Bagaimana cara akses dari HP?
1. Pastikan port 8000 terbuka di firewall
2. Buka browser di HP
3. Akses: `http://[IP_SERVER]:8000`

**Tips:** Pakai VPN (WireGuard) untuk keamanan.

## Troubleshooting

### Emulator tidak mau start
```bash
# Cek logs
docker compose logs cloud-phone

# Cek KVM
ls -la /dev/kvm

# Restart
docker compose down
docker compose up -d
```

### Emulator lambat
1. Pastikan KVM aktif
2. Increase RAM di `.env`: `RAM_SIZE=8192`
3. Pakai GPU: `GPU_ENABLED=true` (butuh NVIDIA GPU)

### Tidak bisa ADB
```bash
# Cek emulator
docker compose ps

# Restart ADB
adb kill-server
adb start-server
adb connect localhost:5555
```

### Web interface tidak bisa diakses
```bash
# Cek port
docker compose ps

# Cek firewall
sudo ufw status
sudo ufw allow 8000

# Cek logs
docker compose logs web-interface
```

### Backup gagal
```bash
# Cek disk space
df -h

# Manual backup
docker compose exec cloud-phone tar -czf /backups/manual-backup.tar.gz -C /data .
```

## Security

### Apakah aman untuk login akun Google?
Aman jika:
1. Pakai password kuat di `.env`
2. Enable VPN untuk akses remote
3. Jangan expose port ke internet tanpa auth

### Bisa pakai untuk banking?
Tidak disarankan. Emulator ini untuk development/testing, bukan untuk sensitive transactions.

### Bagaimana cara reset password?
Edit file `.env`:
```env
AUTH_PASSWORD=password_baru
```
Restart:
```bash
docker compose restart
```

## Deployment

### Oracle Cloud Free Tier bisa?
**Bisa! Ini pilihan terbaik:**
- 4 ARM cores (Ampere A1)
- 24GB RAM
- 200GB storage
- **GRATIS selamanya**

Tutorial:
1. Daftar Oracle Cloud
2. Create VM Instance (Ampere A1)
3. Install Docker
4. Clone repo & run

### DigitalOcean $200 credit bisa?
Bisa, tapi pastikan pakai droplet dengan KVM:
- 4 vCPU
- 8GB RAM
- SSD 100GB

### Google Cloud $300 credit bisa?
Bisa! Pakai `e2-standard-4` instance.

## Performance

### Bagaimana cara improve performance?
1. **KVM**: Pastikan aktif
2. **RAM**: Minimal 8GB
3. **Storage**: Pakai SSD
4. **Network**: Pakai koneksi stabil
5. **Optimasi**: Disable animasi (otomatis)

### Bisa main game Android?
Bisa, tapi:
- Game ringan: Smooth
- Game berat: Mungkin lag
- Game 3D: Butuh GPU passthrough

### Berapa FPS yang didapat?
- **Without GPU**: 15-30 FPS
- **With GPU**: 30-60 FPS
- **With KVM**: 60+ FPS

## Support

### Dimana dapat bantuan?
- GitHub Issues: https://github.com/0xN404T/cloud-phone/issues
- Telegram: @aiueth

### Bagaimana cara report bug?
1. Cek logs: `docker compose logs`
2. Screenshot error
3. Buat issue di GitHub

### Bisa request fitur?
Bisa! Buat issue di GitHub dengan label "enhancement".

---

*Punya pertanyaan lain? Buat issue di GitHub!*
