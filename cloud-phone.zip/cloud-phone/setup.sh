#!/bin/bash
# Cloud Phone - Setup Script
# Quick installation and configuration

set -e

echo "📱 Cloud Phone Setup"
echo "===================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "⚠️ Please run as root: sudo ./setup.sh"
    exit 1
fi

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo "📦 Installing Docker Compose..."
    apt-get update
    apt-get install -y docker-compose-plugin
fi

# Check KVM
echo "🔍 Checking KVM support..."
if [ ! -e /dev/kvm ]; then
    echo "❌ KVM not available!"
    echo ""
    echo "KVM is required for hardware acceleration."
    echo "You need a VPS/cloud VM with nested virtualization support."
    echo ""
    echo "Free options:"
    echo "  - Oracle Cloud Free Tier (Ampere A1)"
    echo "  - Google Cloud ($300 free credit)"
    echo "  - AWS EC2 (12 months free)"
    exit 1
fi

if ! [ -r /dev/kvm ] || ! [ -w /dev/kvm ]; then
    echo "🔧 Fixing KVM permissions..."
    chmod 666 /dev/kvm
fi

echo "✅ KVM available!"

# Create .env if not exists
if [ ! -f .env ]; then
    echo "📝 Creating configuration..."
    cp .env.example .env

    # Generate random password
    RANDOM_PASS=$(openssl rand -base64 12)
    sed -i "s/AUTH_PASSWORD=.*/AUTH_PASSWORD=${RANDOM_PASS}/" .env
    sed -i "s/WEB_PASSWORD=.*/WEB_PASSWORD=${RANDOM_PASS}/" .env
    sed -i "s/GRAFANA_PASSWORD=.*/GRAFANA_PASSWORD=${RANDOM_PASS}/" .env

    echo ""
    echo "🔑 Generated passwords (save these!):"
    echo "   Web Interface: ${RANDOM_PASS}"
    echo ""
    echo "⚠️ Edit .env to customize settings!"
fi

# Create directories
echo "📁 Creating directories..."
mkdir -p data backups extras/apks vpn/config monitoring/grafana

# Set permissions
chmod +x *.sh 2>/dev/null || true
chmod 755 data backups

# Pull images (or build)
echo "📦 Pulling/building Docker images..."
docker compose pull 2>/dev/null || docker compose build

echo ""
echo "✅ Setup complete!"
echo ""
echo "🚀 To start Cloud Phone:"
echo "   docker compose up -d"
echo ""
echo "🌐 Access:"
echo "   Web Interface: http://localhost:8000"
echo "   ADB:           adb connect localhost:5555"
echo ""
echo "📖 Read README.md for full documentation!"
