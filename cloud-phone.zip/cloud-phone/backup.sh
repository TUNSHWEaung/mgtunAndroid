#!/bin/bash
# Cloud Phone - Backup Script
# Backs up emulator data and configuration

set -e

BACKUP_DIR="${BACKUP_DIR:-/backups}"
RETAIN_COUNT="${BACKUP_RETAIN:-7}"
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
BACKUP_NAME="cloud-phone-${TIMESTAMP}"

echo "💾 Starting backup: ${BACKUP_NAME}"

# Create backup directory
mkdir -p "${BACKUP_DIR}"

# Pause emulator for consistent backup
echo "⏸️ Pausing emulator..."
adb shell "su -c 'stop zygote'" 2>/dev/null || true
sleep 5

# Backup emulator data
echo "📦 Backing up emulator data..."
tar -czf "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" \
    --exclude='*.lock' \
    --exclude='cache/*' \
    -C /data .

# Resume emulator
echo "▶️ Resuming emulator..."
adb shell "su -c 'start zygote'" 2>/dev/null || true

# Clean up old backups
echo "🧹 Cleaning old backups..."
cd "${BACKUP_DIR}"
ls -t cloud-phone-*.tar.gz 2>/dev/null | tail -n +$((RETAIN_COUNT + 1)) | xargs rm -f 2>/dev/null || true

# Show backup info
BACKUP_SIZE=$(du -h "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" | cut -f1)
echo "✅ Backup complete: ${BACKUP_NAME} (${BACKUP_SIZE})"

# List all backups
echo ""
echo "📁 Available backups:"
ls -lh "${BACKUP_DIR}"/cloud-phone-*.tar.gz 2>/dev/null || echo "  No backups found"
