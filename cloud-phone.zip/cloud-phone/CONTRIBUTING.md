# Contributing to Cloud Phone

Thank you for your interest in contributing to Cloud Phone! 🎉

## How to Contribute

### 🐛 Reporting Bugs

1. Check if the bug has already been reported in [Issues](https://github.com/0xN404T/cloud-phone/issues)
2. Create a new issue with:
   - Clear title and description
   - Steps to reproduce
   - Expected vs actual behavior
   - Environment details (OS, Docker version, etc.)

### 💡 Suggesting Features

1. Check existing [Issues](https://github.com/0xN404T/cloud-phone/issues) and [Discussions](https://github.com/0xN404T/cloud-phone/discussions)
2. Open a new issue with the "enhancement" label
3. Describe the feature and its benefits

### 🔧 Code Contributions

1. **Fork** the repository
2. **Clone** your fork:
   ```bash
   git clone https://github.com/YOUR-USERNAME/cloud-phone.git
   cd cloud-phone
   ```
3. **Create a branch**:
   ```bash
   git checkout -b feature/your-feature-name
   ```
4. **Make changes** and test locally
5. **Commit** with clear messages:
   ```bash
   git commit -m "feat: add your feature description"
   ```
6. **Push** to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```
7. **Create Pull Request** to `main` branch

## Development Setup

### Prerequisites

- Docker & Docker Compose
- Git
- Text editor (VS Code recommended)

### Local Development

1. Clone the repo:
   ```bash
   git clone https://github.com/0xN404T/cloud-phone.git
   cd cloud-phone
   ```

2. Copy environment:
   ```bash
   cp .env.example .env
   ```

3. Start development:
   ```bash
   make setup
   make start
   ```

## Code Style

- Shell scripts: Use [ShellCheck](https://www.shellcheck.net/)
- Dockerfiles: Follow best practices
- YAML: 2-space indentation
- Markdown: Standard formatting

## Commit Convention

We follow [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` new feature
- `fix:` bug fix
- `docs:` documentation
- `style:` formatting
- `refactor:` code restructuring
- `test:` testing
- `chore:` maintenance

Example: `feat: add ARM64 translation support`

## Pull Request Process

1. Update documentation if needed
2. Add tests for new features
3. Ensure all tests pass
4. Request review from maintainers

## Questions?

- Open a [Discussion](https://github.com/0xN404T/cloud-phone/discussions)
- Telegram: @aiueth

---

Thank you for contributing! 🚀
