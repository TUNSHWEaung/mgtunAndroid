#!/bin/bash
# Cloud Phone - Snapshot Script
# Create and restore emulator snapshots

set -e

SNAPSHOT_DIR="/data/snapshots"
ACTION="$1"
SNAPSHOT_NAME="$2"

# Show usage
if [ -z "$ACTION" ]; then
    echo "Usage: $0 <action> [snapshot-name]"
    echo ""
    echo "Actions:"
    echo "  create <name>  - Create a snapshot"
    echo "  restore <name> - Restore a snapshot"
    echo "  list          - List all snapshots"
    echo "  delete <name> - Delete a snapshot"
    exit 1
fi

mkdir -p "${SNAPSHOT_DIR}"

case "${ACTION}" in
    create)
        if [ -z "$SNAPSHOT_NAME" ]; then
            SNAPSHOT_NAME="snapshot-$(date +%Y%m%d-%H%M%S)"
        fi

        echo "📸 Creating snapshot: ${SNAPSHOT_NAME}"

        # Pause emulator
        adb shell "su -c 'stop zygote'" 2>/dev/null || true
        sleep 2

        # Create snapshot
        tar -czf "${SNAPSHOT_DIR}/${SNAPSHOT_NAME}.tar.gz" \
            -C /data \
            android.avd

        # Resume emulator
        adb shell "su -c 'start zygote'" 2>/dev/null || true

        SNAPSHOT_SIZE=$(du -h "${SNAPSHOT_DIR}/${SNAPSHOT_NAME}.tar.gz" | cut -f1)
        echo "✅ Snapshot created: ${SNAPSHOT_NAME} (${SNAPSHOT_SIZE})"
        ;;

    restore)
        if [ -z "$SNAPSHOT_NAME" ]; then
            echo "❌ Please specify snapshot name"
            exit 1
        fi

        if [ ! -f "${SNAPSHOT_DIR}/${SNAPSHOT_NAME}.tar.gz" ]; then
            echo "❌ Snapshot not found: ${SNAPSHOT_NAME}"
            echo ""
            echo "Available snapshots:"
            ls -1 "${SNAPSHOT_DIR}"/*.tar.gz 2>/dev/null | xargs -n1 basename | sed 's/.tar.gz//'
            exit 1
        fi

        echo "🔄 Restoring snapshot: ${SNAPSHOT_NAME}"

        # Stop emulator
        adb emu kill 2>/dev/null || true
        pkill -f "emulator.*android" 2>/dev/null || true
        sleep 5

        # Remove current AVD
        rm -rf /data/android.avd

        # Restore snapshot
        tar -xzf "${SNAPSHOT_DIR}/${SNAPSHOT_NAME}.tar.gz" -C /data

        echo "✅ Snapshot restored: ${SNAPSHOT_NAME}"
        echo "🔄 Restart container to apply: docker compose restart"
        ;;

    list)
        echo "📸 Available snapshots:"
        echo ""
        if [ "$(ls -A ${SNAPSHOT_DIR}/*.tar.gz 2>/dev/null)" ]; then
            ls -lh "${SNAPSHOT_DIR}"/*.tar.gz | awk '{print "  "$9, "(" $5 ")"}'
        else
            echo "  No snapshots found"
        fi
        ;;

    delete)
        if [ -z "$SNAPSHOT_NAME" ]; then
            echo "❌ Please specify snapshot name"
            exit 1
        fi

        if [ -f "${SNAPSHOT_DIR}/${SNAPSHOT_NAME}.tar.gz" ]; then
            rm -f "${SNAPSHOT_DIR}/${SNAPSHOT_NAME}.tar.gz"
            echo "✅ Snapshot deleted: ${SNAPSHOT_NAME}"
        else
            echo "❌ Snapshot not found: ${SNAPSHOT_NAME}"
        fi
        ;;

    *)
        echo "❌ Unknown action: ${ACTION}"
        echo "Use: create, restore, list, or delete"
        exit 1
        ;;
esac
