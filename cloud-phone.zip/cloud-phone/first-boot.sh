#!/bin/bash
# Cloud Phone - First Boot Script
# This script runs on first boot to set up the emulator

set -e

echo "🚀 Starting first boot setup..."

# Check if setup already completed
if [ -f /data/.setup-complete ]; then
    echo "✅ Setup already completed, skipping..."
    exit 0
fi

# Create necessary directories
mkdir -p /data/android.avd
mkdir -p /backups
mkdir -p /extras/apks

# Wait for AVD to be created
echo "📱 Setting up Android Virtual Device..."
while [ ! -f /data/android.avd/config.ini ]; do
    sleep 2
done

# Apply ARM translation if enabled
if [ "${ARM_TRANSLATION}" = "true" ] && [ -d /opt/ndk-translation ]; then
    echo "🔧 Installing ARM translation layer..."
    cp -r /opt/ndk-translation/* /data/android.avd/ 2>/dev/null || true
fi

# Install custom APKs if present
if [ -d /extras/apks ] && [ "$(ls -A /extras/apks/*.apk 2>/dev/null)" ]; then
    echo "📦 Installing custom APKs..."
    # Will be installed after emulator boots
fi

# Set up backup cron job
if [ "${AUTO_BACKUP}" = "true" ]; then
    echo "💾 Setting up automatic backups..."
    echo "${BACKUP_SCHEDULE:-0 2 * * *} /opt/scripts/backup.sh" > /etc/cron.d/backup
    chmod 0644 /etc/cron.d/backup
    crontab /etc/cron.d/backup
    cron
fi

# Mark setup as complete
touch /data/.setup-complete
echo "✅ First boot setup complete!"
